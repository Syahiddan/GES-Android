package com.example.shidan.ges;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.shidan.ges.model.Place;
import com.example.shidan.ges.model.Plant;
import com.example.shidan.ges.model.PlantState;
import com.example.shidan.ges.model.User;
import com.example.shidan.ges.shidan.PlaceAdapterList;
import com.example.shidan.ges.shidan.Session;
import com.example.shidan.ges.shidan.WebService;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;

public class AdminPlace extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    //use for sorting
    private static final int ASCENDING = 1;
    private static final int DESCENDING = -1;
    private static final int NORMAL = 0;
    String test = "test";
    /////
    DrawerLayout drawer;
    Toolbar toolbar;
    RelativeLayout mainLayout;
    LayoutInflater li;
    View layout;
    WebService ws;
    ListView lv;
    PlaceAdapterList pal;
    ArrayList<Place> places;
    //use for search and filter
    ArrayList<Place> result = new ArrayList<Place>();
    String cur_search_string = "";
    int filter_curr_btn = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        toolbar.setBackgroundColor(Color.GREEN);
        Thread thr1 = new Thread() {
            @Override
            public void run() {
                setup_drawer();
            }
        };
        thr1.start();


        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        mainLayout = (RelativeLayout) findViewById(R.id.admin_content_space);
        li = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        layout = li.inflate(R.layout.activity_admin_place, null);
        mainLayout.removeAllViews();
        mainLayout.addView(layout);

        ws = new WebService(AdminPlace.this);
        lv = (ListView) findViewById(R.id.list_device);
        places = new ArrayList<Place>();
        Thread thread = new Thread() {
            @Override
            public void run() {
                setup_place_list();
                listViewListener();
            }
        };

        thread.start();


    }

    public  void listViewListener()
    {
        try{
            lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    final RelativeLayout root = (RelativeLayout) pal.getView(position,view,parent);
                    final LinearLayout layout_info = (LinearLayout) root.findViewById(R.id.layout_info);
                    final LinearLayout action_layout = (LinearLayout) root.findViewById(R.id.action_layout);
                    final TextView more_detail_btn = (TextView) root.findViewById(R.id.more_detail_btn);
                    final LinearLayout layout_edit = (LinearLayout)root.findViewById(R.id.layout_edit);

                    TextView btn_edit = (TextView) action_layout.findViewById(R.id.btn_edit);
                    TextView btn_delete = (TextView) action_layout.findViewById(R.id.btn_delete);
                    TextView btn_collapse = (TextView) action_layout.findViewById(R.id.btn_collapse);


                    layout_info.setVisibility((layout_info.getVisibility()==View.GONE)? View.VISIBLE:View.GONE);
                    action_layout.setVisibility((layout_info.getVisibility()==View.VISIBLE)?View.VISIBLE:View.GONE);
                    more_detail_btn.setVisibility((layout_info.getVisibility()==View.GONE)?View.VISIBLE:View.GONE);
                    if(layout_info.getVisibility() == View.GONE)
                    {
                        if(layout_edit.getVisibility()==View.VISIBLE)
                        {
                            layout_edit.setVisibility(View.GONE);
                        }
                    }
                    more_detail_btn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Toast.makeText(AdminPlace.this,"ui",Toast.LENGTH_SHORT).show();
                        }
                    });

                    btn_edit.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Log.d(test,"edit btn");

//                            Animation animation = AnimationUtils.loadAnimation(AdminPlace.this, (layout_edit.getVisibility()==View.GONE)?R.anim.scroll_down_anim:R.anim.scroll_up_anim );
//                            layout_edit.startAnimation(animation);
//                            layout_edit.setVisibility((layout_edit.getVisibility()==View.GONE)?View.VISIBLE:View.GONE);
                            if(layout_edit.getVisibility()==View.GONE){
                                Animation animation = AnimationUtils.loadAnimation(AdminPlace.this,R.anim.scroll_down_anim);
                                layout_edit.setAnimation(animation);
                                layout_edit.setVisibility(View.VISIBLE);
                            }
                            else
                            {
                                Animation animation = AnimationUtils.loadAnimation(AdminPlace.this,R.anim.scroll_up_out);
                                layout_edit.setAnimation(animation);
                                animation.setAnimationListener(new Animation.AnimationListener() {
                                    @Override
                                    public void onAnimationStart(Animation animation) {

                                    }

                                    @Override
                                    public void onAnimationEnd(Animation animation) {
                                        layout_edit.setVisibility(View.GONE);
                                    }

                                    @Override
                                    public void onAnimationRepeat(Animation animation) {

                                    }
                                });

                            }
                        }
                    });
                    btn_delete.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Log.d(test,"delete btn");
                            AlertDialog.Builder builder = new AlertDialog.Builder(AdminPlace.this);
                            builder.setMessage("Are you sure?")
                                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            }).show();
                        }
                    });
                    btn_collapse.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Log.d(test,"collapse btn");
                        }
                    });


                }
            });
        }catch (Exception e)
        {
            Log.d(test,e.getLocalizedMessage());
        }

    }

    public void sortingPlace(View view) {
        LinearLayout root = (LinearLayout) view.getParent();
        for (int i = 0; i < root.getChildCount() - 1; i++) {
            Button tempBtn = (Button) root.getChildAt(i);
            tempBtn.setCompoundDrawablesWithIntrinsicBounds(0, 0, 0, 0);
        }
        final Button cur_btn = (Button) view;
        if (cur_btn.getTag() == null) {
            cur_btn.setTag(R.drawable.icon_sorting_down);
            cur_btn.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.icon_sorting_down, 0);
            Thread thread = new Thread() {
                @Override
                public void run() {
                    sorting(pal.getAllData(), (cur_btn).getText().toString(), DESCENDING);
                }
            };
            thread.start();
            (cur_btn.getCompoundDrawables()[2]).setColorFilter(getResources().getColor(R.color.light_slate_blue), PorterDuff.Mode.SRC_ATOP);
        } else {
            cur_btn.setCompoundDrawablesWithIntrinsicBounds(0, 0, ((Integer) cur_btn.getTag()).equals(R.drawable.icon_sorting_down) ? R.drawable.icon_sorting_up : R.drawable.icon_sorting_down, 0);
            Thread thread = new Thread() {
                @Override
                public void run() {
                    sorting(pal.getAllData(), (cur_btn).getText().toString(), ((Integer) cur_btn.getTag()).equals(R.drawable.icon_sorting_down) ? DESCENDING : ASCENDING);
                }
            };
            thread.start();
            cur_btn.setTag(((Integer) cur_btn.getTag()).equals(R.drawable.icon_sorting_down) ? R.drawable.icon_sorting_up : R.drawable.icon_sorting_down);
            (cur_btn.getCompoundDrawables()[2]).setColorFilter(getResources().getColor(R.color.light_slate_blue), PorterDuff.Mode.SRC_ATOP);
        }
    }

    public void setup_place_list() {
        EditText input_place_name = (EditText) findViewById(R.id.input_place_name);
        input_place_name.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.length() == 0) {
                    search_filter(places, "", filter_curr_btn);
                    cur_search_string = "";

                }
            }
        });


        HashMap<Object, Object> params = new HashMap<Object, Object>();
        params.put("function", "fnPlaceList");
        ws.post("", params, new WebService.JSON() {
            @Override
            public void responseData(JSONObject status, JSONObject data) {
//                Log.d(test,status.toString());
                if (status.optString("statusRequest").equals("success")) {

                    if (data != null) {

                        try {
//                            Log.d(test, data.getJSONArray("place").get(0).toString());
                            for (int i = 0; i < data.getJSONArray("place").length(); i++) {
                                JSONObject temp = (JSONObject) data.getJSONArray("place").get(i);
//                                Log.d(test,temp.toString());
                                Place place_temp = new Place(temp.getString("name"));
                                place_temp.setPlace_id(temp.optString("id"));
                                place_temp.setPlace_name(temp.getString("name"));

                                Plant plant_temp = new Plant(temp.optInt("plant_id"));
                                JSONObject temp2 = (JSONObject) temp.getJSONObject("plant_detail");
                                plant_temp.setId(temp.optInt("plant_id"));
                                plant_temp.setName(temp2.optString("name"));
                                plant_temp.setScientific_name(temp2.optString("scientific_name"));
                                plant_temp.setDescription(temp2.optString("description"));
                                plant_temp.setImage(temp2.optString("image"));
                                place_temp.setPlant(plant_temp);

                                PlantState plantState_temp = new PlantState();
                                JSONObject temp3 = (JSONObject) temp.getJSONObject("plant_state_info");
                                plantState_temp.setCode(temp3.optString("code"));
                                plantState_temp.setState_name(temp3.optString("state_name"));
                                plantState_temp.setHumidity(Float.valueOf(temp3.optString("humidity")));
                                plantState_temp.setTemperature(Float.valueOf(temp3.optString("temperature")));
                                place_temp.setPlantState(plantState_temp);

                                User user_temp = new User();
                                JSONObject temp4 = (JSONObject) temp.getJSONObject("monitor_detail");
                                user_temp.setWorker_id(temp4.optString("worker_id"));
                                user_temp.setFname(temp4.optString("fname"));
                                user_temp.setMidname(temp4.optString("midname"));
                                user_temp.setLname(temp4.optString("lname"));
                                user_temp.setEmail(temp4.optString("email"));
                                user_temp.setPhone(temp4.optString("phone"));
                                user_temp.setImage(temp4.optString("image"));
                                place_temp.setMonitor(user_temp);

                                places.add(place_temp);

                            }
                            pal = new PlaceAdapterList(AdminPlace.this, R.layout.place_arraylist, places);
                        } catch (JSONException e) {

                        }

                    }
                }

                lv.setAdapter(pal);
            }
        });
    }

    public void filterPlaceSearch(View view) {
        final View v = view;
        Thread thread = new Thread() {
            @Override
            public void run() {
                try {
                    EditText temp_search = ((View) v.getParent()).findViewById(R.id.input_place_name);
                    final String temp = temp_search.getText().toString().trim();

                    if (temp.length() > 0) {

                        search_filter(places, temp, filter_curr_btn);
                        cur_search_string = temp;
                    }

                } catch (Exception e) {
                    Log.d(test, e.getLocalizedMessage());
                }
            }
        };
        thread.start();

    }

    public void filterPlacesBtn(View view) {
        try {
            TextView cur_btn = (TextView) view;
            LinearLayout root = (LinearLayout) view.getParent();
            for (int i = 1; i < root.getChildCount(); i++) {
                TextView temp = (TextView) root.getChildAt(i);
                temp.setEnabled(true);
                temp.setBackgroundResource(R.drawable.simple_bubble_btn);
            }
            cur_btn.setEnabled(false);
            cur_btn.setBackgroundResource(R.drawable.custom_btn_success);

            filter_curr_btn = (cur_btn.getText().toString().equals("ALL")) ? 0 : (cur_btn.getText().toString().equals("EXIST")) ? 1 : (cur_btn.getText().toString().equals("NOT EXIST")) ? 2 : -1;
            search_filter(places, cur_search_string, filter_curr_btn);

        } catch (Exception e) {
            Log.d(test, e.getLocalizedMessage());
        }
    }

    private void search_filter(final ArrayList<Place> places, String search, int cur_btn_filter) {
        final ArrayList<Place> temp = new ArrayList<Place>();
        if (search.equals("") && cur_btn_filter <= 0) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    pal = new PlaceAdapterList(AdminPlace.this, R.layout.place_arraylist, places);
                    lv.setAdapter(pal);
                    lv.invalidate();
                }
            });
            Log.d(test, "p");
        } else if (search.equals("") && !(cur_btn_filter <= 0)) {
            if (cur_btn_filter == 1) {
                //fe
                for (int i = 0; i < places.size(); i++) {
                    if (!places.get(i).getMonitor().getFname().equals("") || places.get(i).getMonitor() != null) {
                        temp.add(places.get(i));
                    }
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        pal = new PlaceAdapterList(AdminPlace.this, R.layout.place_arraylist, temp);
                        lv.setAdapter(pal);
                        lv.invalidate();
                    }
                });
                Log.d(test, "fe");
            } else if (cur_btn_filter == 2) {
                //fn
                for (int i = 0; i < places.size(); i++) {
                    if (places.get(i).getMonitor().getFname().equals("") || places.get(i).getMonitor() == null) {
                        temp.add(places.get(i));
                    }
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        pal = new PlaceAdapterList(AdminPlace.this, R.layout.place_arraylist, temp);
                        lv.setAdapter(pal);
                        lv.invalidate();
                    }
                });
                Log.d(test, "fn");
            }
        } else if (!search.equals("") && cur_btn_filter <= 0) {
            //s

            for (int i = 0; i < places.size(); i++) {
                if (places.get(i).getPlace_name().toLowerCase().contains(search.toLowerCase())) {
                    temp.add(places.get(i));
                }
            }
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    pal = new PlaceAdapterList(AdminPlace.this, R.layout.place_arraylist, temp);
                    lv.setAdapter(pal);
                    lv.invalidate();
                }
            });
            Log.d(test, "s");

        } else if (!search.equals("") && !(cur_btn_filter <= 0)) {
            if (cur_btn_filter == 1) {
                //sfe
                //search
                ArrayList<Place> temp2 = new ArrayList<Place>();
                for (int i = 0; i < places.size(); i++) {
                    if (places.get(i).getPlace_name().toLowerCase().contains(search.toLowerCase())) {
                        temp2.add(places.get(i));
                    }
                }
                //filter
                for (int j = 0; j < temp2.size(); j++) {
                    if (temp2.get(j).getMonitor().getFname().length() > 0 || temp2.get(j).getMonitor() != null) {
                        temp.add(temp2.get(j));
                    }
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        pal = new PlaceAdapterList(AdminPlace.this, R.layout.place_arraylist, temp);
                        lv.setAdapter(pal);
                        lv.invalidate();
                    }
                });
                Log.d(test, "sfe");

            } else if (cur_btn_filter == 2) {
                //sfn
                ArrayList<Place> temp2 = new ArrayList<Place>();
                for (int i = 0; i < places.size(); i++) {
                    if (places.get(i).getPlace_name().toLowerCase().equals(search.toLowerCase())) {
                        temp2.add(places.get(i));
                    }
                }
                //filter
                for (int j = 0; j < temp2.size(); j++) {
                    if (temp2.get(j).getMonitor().getFname().length() <= 0 || temp2.get(j).getMonitor() == null) {
                        temp.add(temp2.get(j));
                    }
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        pal = new PlaceAdapterList(AdminPlace.this, R.layout.place_arraylist, temp);
                        lv.setAdapter(pal);
                        lv.invalidate();
                    }
                });
                Log.d(test, "sfn");
            }
        }
        Log.d(test, String.valueOf(temp.size()));
    }

    private void sorting(final ArrayList<Place> places, String category, int sort) {
        //ascending 1
        //descending -1
        //normal 0
//        Log.d(test,category);
        final ArrayList<Place> temp = places;
        if (sort == NORMAL) {
            Log.d(test, "p");
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    pal = new PlaceAdapterList(AdminPlace.this, R.layout.place_arraylist, places);
                    lv.setAdapter(pal);
                    lv.invalidate();
                }
            });

        } else {
            if (sort == ASCENDING) {

                if (category.equals("NAME") || category.equals("Name")) {
                    Comparator<Place> compareByPlaceNameAsc = new Comparator<Place>() {
                        @Override
                        public int compare(Place o1, Place o2) {
                            return o1.getPlace_name().compareTo(o2.getPlace_name());
                        }
                    };
                    Collections.sort(temp, compareByPlaceNameAsc);
                    Log.d(test, "sa name");
                } else if (category.equals("GUARDIAN") || category.equals("Guardian")) {
                    Comparator<Place> compareByPlaceGuardianAsc = new Comparator<Place>() {
                        @Override
                        public int compare(Place o1, Place o2) {
                            return o1.getMonitor().getFname().compareTo(o2.getMonitor().getFname());
                        }
                    };
                    Collections.sort(temp, compareByPlaceGuardianAsc);
                    Log.d(test, "sa guardian");
                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        pal = new PlaceAdapterList(AdminPlace.this, R.layout.place_arraylist, temp);
                        lv.setAdapter(pal);
                        lv.invalidate();
                    }
                });

            } else if (sort == DESCENDING) {
                if (category.equals("NAME") || category.equals("Name")) {
                    Comparator<Place> compareByPlaceNamedesc = new Comparator<Place>() {
                        @Override
                        public int compare(Place o1, Place o2) {
                            return o2.getPlace_name().compareTo(o1.getPlace_name());
                        }
                    };
                    Collections.sort(temp, compareByPlaceNamedesc);
                    Log.d(test, "sd name");
                } else if (category.equals("GUARDIAN") || category.equals("Guardian")) {
                    Comparator<Place> compareByPlaceGuardiandesc = new Comparator<Place>() {
                        @Override
                        public int compare(Place o1, Place o2) {
                            return o2.getMonitor().getFname().compareTo(o1.getMonitor().getFname());
                        }
                    };
                    Collections.sort(temp, compareByPlaceGuardiandesc);
                    Log.d(test, "sd guardian");
                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        pal = new PlaceAdapterList(AdminPlace.this, R.layout.place_arraylist, temp);
                        lv.setAdapter(pal);
                        lv.invalidate();
                    }
                });
            }
        }
    }

    public void open_filter_layout(View view) {
        RelativeLayout root = (RelativeLayout) view.getParent().getParent();
        LinearLayout tool_footer = root.findViewById(R.id.tool_footer);
        tool_footer.setVisibility((tool_footer.getVisibility() == View.GONE) ? View.VISIBLE : View.GONE);

    }

    public void setup_drawer() {
        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.admin, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.

        int id = item.getItemId();

        if (id == R.id.drawer_device_menu) {
//            ld = new LoadingDialog();
//            ld.show(getSupportFragmentManager(),"uinaaaaaa");
//            new Handler().postDelayed(new Runnable() {
//                @Override
//                public void run() {
//                    ld.dismiss();
//                }
//            },2000);
            Intent intent = new Intent(AdminPlace.this, AdminDevice.class);
            startActivity(intent);
        } else if (id == R.id.drawer_staff_menu) {
            Intent intent = new Intent(AdminPlace.this, AdminWorker.class);
            startActivity(intent);

        } else if (id == R.id.drawer_setting_menu) {
        } else if (id == R.id.drawer_logout_menu) {
            Session.setCurrentContext(Login.class);
            Session.setUser(null);
            Intent intent = new Intent(AdminPlace.this, Login.class);
            startActivity(intent);
            finish();
        }
//
//

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
